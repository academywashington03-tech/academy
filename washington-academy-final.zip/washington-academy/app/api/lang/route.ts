import { NextRequest, NextResponse } from "next/server";

export function GET(req: NextRequest) {
  const l = req.nextUrl.searchParams.get("l") === "en" ? "en" : "ar";
  // Only allow same-site relative redirects (prevents open redirect).
  const ref = req.headers.get("referer");
  let fromRef = "/";
  try { if (ref) { const u = new URL(ref); if (u.origin === req.nextUrl.origin) fromRef = u.pathname + u.search; } } catch {}
  const back = req.nextUrl.searchParams.get("back") ?? fromRef;
  const safe = back.startsWith("/") && !back.startsWith("//") ? back : "/";
  const res = NextResponse.redirect(new URL(safe, req.url));
  res.cookies.set("lang", l, { path: "/", maxAge: 60 * 60 * 24 * 365, sameSite: "lax" });
  return res;
}
